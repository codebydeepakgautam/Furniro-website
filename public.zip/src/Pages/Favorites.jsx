import React from 'react';

const Favorites = () => {
  return <div className="pt-20 ">Tdvdfjvjiohdf</div>;
};

export default  Favorites ;
