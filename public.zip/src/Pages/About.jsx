import React from 'react';

import ProductDetail from '../Components/ProductDetail';
import Description from '../Components/Description'
import  Products from '../Components/Related Products'
 
const User = () => {
  return <div className="pt-20 ">
    <ProductDetail/>
    <Description/>
    < Products/>
    
    
    

  </div>;
};

export default User;
