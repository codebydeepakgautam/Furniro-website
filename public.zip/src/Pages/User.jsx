import React from 'react';

const user = () => {
  return <div className="pt-20 ">
    fgfdgcfvdfg
  </div>;
};

export default user;
