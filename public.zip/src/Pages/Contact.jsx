import React from 'react';
 import Head from '../Components/Head'
 import Deatils from '../Components/Deatils'
 import Quality from '../Components/Quality'

const Contact = () => {
  return <div className="pt-20">

    <Head/>
    <Deatils/>
    <Quality/>
  </div>;
};

export default Contact;
