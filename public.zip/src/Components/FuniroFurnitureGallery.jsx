import React from 'react'

function FuniroFurnitureGallery() {
  return (
    <div>
      
    </div>
  )
}

export default FuniroFurnitureGallery
